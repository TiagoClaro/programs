#ifndef ARROW_H
#define ARROW_H

#include <Arduino.h>
#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <Adafruit_GFX.h>

void arrow_angle(float angle);

#endif